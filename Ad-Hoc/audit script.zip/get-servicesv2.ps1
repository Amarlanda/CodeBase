$username = "wycombe\supportamarlanda"
$password = "Dragoncontrol101"
$secstr = New-Object -TypeName System.Security.SecureString
$password.ToCharArray() | ForEach-Object {$secstr.AppendChar($_)}
$cred = new-object -typename System.Management.Automation.PSCredential -argumentlist $username, $secstr


$a = Get-Content "C:\VMs.txt"

foreach ($i in $a)
    {$i + "`n" + "==========================";Get-WmiObject -credential $cred Win32_Service -ComputerName $i | where-object {$_.startname -like "*.\admin*"} |Select-Object Name, Description, StartMode, State, Status, StartName
    }

