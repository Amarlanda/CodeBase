#$Computer = [ADSI]"WinNT://$Env:wdc-vm-ts02,Computer"
#$LocalAdmin.SetPassword("London123")
#$LocalAdmin.SetInfo()
#$LocalAdmin.FullName = "Local Admin by Powershell"
#$LocalAdmin.SetInfo()
#$LocalAdmin.UserFlags = 64 + 65536 # ADS_UF_PASSWD_CANT_CHANGE + ADS_UF_DONT_EXPIRE_PASSWD
#$LocalAdmin.SetInfo()


$admin=[adsi]("WinNT://wdc-vm-ts02/administrator, user")
$admin.psbase.invoke("SetPassword", "London123")