$objOu = [ADSI]"WinNT://wdc0886" # MAzza
#$objOu = [ADSI]"WinNT://wdc-vdi-204" # amar productions
#$objOu = [ADSI]"WinNT://wdc-vdi-m-039" # ben
#$objOu = [ADSI]"WinNT://172.18.253.100" #xp

$objUser = $objOU.Create("User", "yesmaz")
$objUser.setpassword("London123")
$objUser.SetInfo()
$objUser.description = "description"
$objUser.SetInfo()
$objUser.UserFlags = 64 + 65536 # ADS_UF_PASSWD_CANT_CHANGE + ADS_UF_DONT_EXPIRE_PASSWD
$objUser.SetInfo()
Start-Sleep -s 5

$Group=[ADSI]"WinNT://wdc0886/Administrators,Group"
$Group.Add($objUser.path)